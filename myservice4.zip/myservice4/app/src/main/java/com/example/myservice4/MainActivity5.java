package com.example.myservice4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {
    EditText st2_search;
    Button btn2_search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        st2_search = findViewById(R.id.st2_search);
        btn2_search = findViewById(R.id.btn2_search);
        configureclick2();

        //search function
        btn2_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchTerms = st2_search.getText().toString();
                if (!searchTerms.equals("")) {
                    searchNet(searchTerms);
                }
            }
        });
        service();
    }

    //identifying service and connecting
    private void service() {
        ImageButton startservice2 = findViewById(R.id.startservice2);
        startservice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(new Intent(MainActivity5.this, coma_service.class));
            }

        });
        ImageButton stopService2 = findViewById(R.id.stopservice2);
        stopService2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity5.this, coma_service.class));
            }
        });
    }

    //seach engine
    public void searchNet(String words){
        try {
            Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
            intent.putExtra(SearchManager.QUERY, words);
            startActivity(intent);
        } catch (ActivityNotFoundException e){
            e.printStackTrace();
            searchNetCompat(words);
        }
    }
    public void searchNetCompat(String words){
        try {
            Uri uri = Uri.parse("http://www.google.com/#q="+words);
            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(intent);
        } catch (ActivityNotFoundException e){
            e.printStackTrace();
            Toast.makeText(this,"Error!",Toast.LENGTH_SHORT).show();
        }
    }

    //back button
    private void configureclick2() {
        Button click2 = findViewById(R.id.click2);
        click2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}