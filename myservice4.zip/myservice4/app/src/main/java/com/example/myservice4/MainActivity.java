package com.example.myservice4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText email1, password1;
    Button btn_save, btn_load, open , apiButton ;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    //wifi_broadcast(reciever)
        wifi_connection receiver=new wifi_connection();
        IntentFilter filter1= new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);
        registerReceiver(receiver,filter1);

    //shared prefrences to save the data
        sp = getSharedPreferences("store", MODE_PRIVATE);
        if (sp.getBoolean("flag", false)) {
            startActivity(new Intent(MainActivity.this, MainActivity2.class));
        } else {
            email1 = findViewById(R.id.email);
            password1 = findViewById(R.id.password);
            btn_save = (Button) findViewById(R.id.btn_save);
            btn_load = (Button) findViewById(R.id.btn_load);
            btn_load.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences sp = getSharedPreferences("store", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("email", email1.getText().toString());
                    editor.putString("password", password1.getText().toString());
                    editor.apply();
                    startActivity(new Intent(MainActivity.this, MainActivity2.class));
                }
            });
        }

    //open button
        configureopen();
    }
    private void configureopen () {
        Button open = findViewById(R.id.open);
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, MainActivity3.class));
                }
        });
        Button apiButton=(Button) findViewById(R.id.apiButton);
        apiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ApiActivity.class));
            }
        });

    }
    }
    //RES.drawable for saving pictures
    //RES.layout for XML
    //RES.raw for saving the music
