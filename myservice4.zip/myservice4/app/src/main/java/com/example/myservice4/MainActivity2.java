package com.example.myservice4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.TextView;

//screen for monitering the data which will be save in dev file explorer because of SHAREDPREFRENCES

public class MainActivity2 extends AppCompatActivity {
TextView tv_email,tv_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tv_email = (TextView) findViewById(R.id.tv_email);
        tv_password = (TextView) findViewById(R.id.tv_password);

        //USING IT WITH PRIVATE MODE
        SharedPreferences sp= getSharedPreferences("store",MODE_PRIVATE);

        //default value for both text
        String email =sp.getString("email","Not Found");
        String password =sp.getString("password","Not Found");

        //using the set text
        tv_password.setText(password);
        tv_email.setText(email);
    }
}