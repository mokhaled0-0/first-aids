package com.example.myservice4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
EditText st_search;
Button btn_search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        configureclick1();
        st_search = findViewById(R.id.st_search);
        btn_search = findViewById(R.id.btn_search);

    //search function
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchTerms = st_search.getText().toString();
                if (!searchTerms.equals("")) {
                    searchNet(searchTerms);
                }
            }
        });
        service();
    }

    //idintifying the service and connecting it
    private void service() {
        ImageButton startservice1 = findViewById(R.id.startservice1);
        startservice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(new Intent(MainActivity4.this, fire_service.class));
            }

        });
        ImageButton stopService1 = findViewById(R.id.stopservice1);
        stopService1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity4.this, fire_service.class));
            }
        });
    }

    //search engine
    public void searchNet(String words){
        try {
            Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
            intent.putExtra(SearchManager.QUERY, words);
            startActivity(intent);
        } catch (ActivityNotFoundException e){
            e.printStackTrace();
            searchNetCompat(words);
        }
    }
    public void searchNetCompat(String words){
        try {
            Uri uri = Uri.parse("http://www.google.com/#q="+words);
            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
            startActivity(intent);
        } catch (ActivityNotFoundException e){
            e.printStackTrace();
            Toast.makeText(this,"Error!",Toast.LENGTH_SHORT).show();
        }
    }

    //back button
    private void configureclick1() {
        Button click1 = findViewById(R.id.click1);
        click1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}