package com.example.myservice4;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

//for playing the music

public class fire_service extends Service {
    MediaPlayer mp;
    public fire_service() {

    }
    public void onCreate() {
        super.onCreate();
        mp = MediaPlayer.create(this, R.raw.fire_alarm);
    }
    public int onStartCommand(Intent intent,int flags, int startid){
        if(!mp.isPlaying())
            mp.start();
        return START_STICKY;
    }
    public void onDestroy() {
        super.onDestroy();
        if(mp.isPlaying()){
            mp.stop();
            mp.release();
        }

    }
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}